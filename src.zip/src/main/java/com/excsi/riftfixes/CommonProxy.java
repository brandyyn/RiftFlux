package com.excsi.riftfixes;

public class CommonProxy {
    public void initClientFeatures() { /* no-op on server */ }
}
