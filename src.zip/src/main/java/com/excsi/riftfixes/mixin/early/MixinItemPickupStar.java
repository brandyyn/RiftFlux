package com.excsi.riftfixes.mixin.early;

import com.excsi.riftfixes.ModConfig;
import com.excsi.riftfixes.Constants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(GuiContainer.class)
public abstract class MixinItemPickupStar {

    @Shadow protected int guiLeft;
    @Shadow protected int guiTop;
    @Shadow public Container inventorySlots;

    @Unique private static final String TAG = "riftfixes_new";
    @Unique private static final ResourceLocation TEX =
            new ResourceLocation(Constants.MODID, "textures/gui/pickup_star.png"); // 16x16 PNG

    @Inject(method = "drawScreen(IIF)V", at = @At("TAIL"))
    private void rf$drawStarsAndClear(int mouseX, int mouseY, float pt, CallbackInfo ci) {
        if (!ModConfig.enableItemPickupStar) return;
        if (!(inventorySlots instanceof ContainerPlayer)) return;

        @SuppressWarnings("rawtypes")
        List slots = inventorySlots.inventorySlots;
        if (slots == null) return;

        // Clear tag on hovered stack
        for (Object o : slots) {
            Slot s = (Slot) o;
            int x0 = guiLeft + s.xDisplayPosition;
            int y0 = guiTop + s.yDisplayPosition;
            if (mouseX >= x0 && mouseY >= y0 && mouseX < x0 + 16 && mouseY < y0 + 16) {
                ItemStack st = s.getStack();
                if (st != null && st.hasTagCompound()) {
                    NBTTagCompound tag = st.getTagCompound();
                    if (tag.getBoolean(TAG)) {
                        tag.removeTag(TAG);
                        if (tag.hasNoTags()) st.setTagCompound(null);
                    }
                }
                break;
            }
        }

        // Draw overlay on any stack still carrying the tag
        final Minecraft mc = Minecraft.getMinecraft();
        mc.getTextureManager().bindTexture(TEX);

        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1F, 1F, 1F, 1F);

        for (Object o : slots) {
            Slot s = (Slot) o;
            ItemStack st = s.getStack();
            if (st == null || !st.hasTagCompound() || !st.getTagCompound().getBoolean(TAG)) continue;

            int x = guiLeft + s.xDisplayPosition; // exact 16x16 cover
            int y = guiTop  + s.yDisplayPosition;
            Tessellator t = Tessellator.instance;
            t.startDrawingQuads();
            t.addVertexWithUV(x    , y+16, 0, 0, 1);
            t.addVertexWithUV(x+16 , y+16, 0, 1, 1);
            t.addVertexWithUV(x+16 , y   , 0, 1, 0);
            t.addVertexWithUV(x    , y   , 0, 0, 0);
            t.draw();
        }

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_LIGHTING);
    }
}
